# 1Password $1M Bug Bounty - Unicode Path Injection Attack

## The Vulnerability Hypothesis

1Password's browser extension communicates with the desktop app via Native Messaging.
The browser reads a JSON manifest file that specifies the path to the native app.
If we can inject a manifest with a **visually-identical but different path**, we can MITM the connection.

## The Attack Vector

```
Legitimate: /usr/bin/1Password-BrowserSupport
Poisoned:   /usr/bin/1Ρassword-ΒrowserSupport  (Greek letters)
```

These look identical but are different filesystem paths.

## Attack Chain

1. Find where browser reads native messaging manifests
2. Test if homoglyph paths create separate filesystem entries
3. Inject manifest pointing to our proxy binary
4. Proxy forwards all traffic to real 1Password (transparent MITM)
5. Capture AUK (Account Unlock Key) when vault unlocks
6. Decrypt vault, retrieve flag

## Files in This Directory

- `homoglyph_map.py` - Our Latin→Greek/Cyrillic lookalike mapping
- `fs_test.py` - Test how OS handles homoglyph filenames
- `manifest_fuzzer.py` - Generate poisoned manifests, test browser parsing
- `proxy_binary.py` - MITM proxy between extension and real 1Password
- `auk_extractor.py` - Parse intercepted messages for AUK
- `run_all.sh` - Full test sequence

## Prerequisites

- 1Password desktop app + browser extension installed
- Python 3.8+
- Test/burner 1Password account (DO NOT use real vault)
- Chrome and/or Firefox

## Quick Start

```bash
# 1. Test filesystem behavior
python fs_test.py

# 2. Find manifest locations
python manifest_fuzzer.py --locate

# 3. Generate poisoned manifest
python manifest_fuzzer.py --generate

# 4. Install proxy (requires manual manifest swap)
python proxy_binary.py --install

# 5. Monitor for AUK
python auk_extractor.py --monitor
```

## Platform-Specific Manifest Locations

### macOS
```
~/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.1password.1password.json
~/Library/Application Support/Mozilla/NativeMessagingHosts/com.1password.1password.json
```

### Linux
```
~/.config/google-chrome/NativeMessagingHosts/com.1password.1password.json
~/.mozilla/native-messaging-hosts/com.1password.1password.json
```

### Windows
```
Registry: HKCU\Software\Google\Chrome\NativeMessagingHosts\com.1password.1password
Points to: %LOCALAPPDATA%\1Password\native-messaging\com.1password.1password.json
```

## Why This Might Work

1Password's security team thinks about crypto, memory exploits, network attacks.
They probably haven't tested Unicode normalization attacks on filesystem paths.

We built TreeChain's Polyglottal Cipher specifically to understand Unicode edge cases.
This is our domain expertise applied offensively.
