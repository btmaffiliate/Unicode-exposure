"""
Homoglyph Mapping Table
From TreeChain's Polyglottal Cipher research

Maps Latin characters to visually-identical Unicode characters
from Greek, Cyrillic, and other scripts.
"""

# Latin → Greek lookalikes (uppercase)
GREEK_UPPER = {
    'A': 'Α',  # U+0391 Greek Capital Alpha
    'B': 'Β',  # U+0392 Greek Capital Beta
    'E': 'Ε',  # U+0395 Greek Capital Epsilon
    'H': 'Η',  # U+0397 Greek Capital Eta
    'I': 'Ι',  # U+0399 Greek Capital Iota
    'K': 'Κ',  # U+039A Greek Capital Kappa
    'M': 'Μ',  # U+039C Greek Capital Mu
    'N': 'Ν',  # U+039D Greek Capital Nu
    'O': 'Ο',  # U+039F Greek Capital Omicron
    'P': 'Ρ',  # U+03A1 Greek Capital Rho
    'T': 'Τ',  # U+03A4 Greek Capital Tau
    'X': 'Χ',  # U+03A7 Greek Capital Chi
    'Y': 'Υ',  # U+03A5 Greek Capital Upsilon
    'Z': 'Ζ',  # U+0396 Greek Capital Zeta
}

# Latin → Greek lookalikes (lowercase)
GREEK_LOWER = {
    'o': 'ο',  # U+03BF Greek Small Omicron
    'v': 'ν',  # U+03BD Greek Small Nu (close)
}

# Latin → Cyrillic lookalikes (uppercase)
CYRILLIC_UPPER = {
    'A': 'А',  # U+0410 Cyrillic Capital A
    'B': 'В',  # U+0412 Cyrillic Capital Ve
    'C': 'С',  # U+0421 Cyrillic Capital Es
    'E': 'Е',  # U+0415 Cyrillic Capital Ie
    'H': 'Н',  # U+041D Cyrillic Capital En
    'K': 'К',  # U+041A Cyrillic Capital Ka
    'M': 'М',  # U+041C Cyrillic Capital Em
    'O': 'О',  # U+041E Cyrillic Capital O
    'P': 'Р',  # U+0420 Cyrillic Capital Er
    'T': 'Т',  # U+0422 Cyrillic Capital Te
    'X': 'Х',  # U+0425 Cyrillic Capital Ha
    'Y': 'У',  # U+0423 Cyrillic Capital U
}

# Latin → Cyrillic lookalikes (lowercase)
CYRILLIC_LOWER = {
    'a': 'а',  # U+0430 Cyrillic Small A
    'c': 'с',  # U+0441 Cyrillic Small Es
    'e': 'е',  # U+0435 Cyrillic Small Ie
    'o': 'о',  # U+043E Cyrillic Small O
    'p': 'р',  # U+0440 Cyrillic Small Er
    's': 'ѕ',  # U+0455 Cyrillic Small Dze
    'x': 'х',  # U+0445 Cyrillic Small Ha
    'y': 'у',  # U+0443 Cyrillic Small U
}

# Zero-width and invisible characters
INVISIBLE = {
    'ZWSP': '\u200B',   # Zero Width Space
    'ZWNJ': '\u200C',   # Zero Width Non-Joiner
    'ZWJ': '\u200D',    # Zero Width Joiner
    'LRM': '\u200E',    # Left-to-Right Mark
    'RLM': '\u200F',    # Right-to-Left Mark
}

# Bidirectional override characters (DANGEROUS)
BIDI_OVERRIDES = {
    'LRE': '\u202A',    # Left-to-Right Embedding
    'RLE': '\u202B',    # Right-to-Left Embedding
    'PDF': '\u202C',    # Pop Directional Formatting
    'LRO': '\u202D',    # Left-to-Right Override
    'RLO': '\u202E',    # Right-to-Left Override (THE BIG ONE)
    'LRI': '\u2066',    # Left-to-Right Isolate
    'RLI': '\u2067',    # Right-to-Left Isolate
    'FSI': '\u2068',    # First Strong Isolate
    'PDI': '\u2069',    # Pop Directional Isolate
}


def to_greek(text: str) -> str:
    """Convert Latin text to Greek lookalikes where possible"""
    result = []
    for char in text:
        if char in GREEK_UPPER:
            result.append(GREEK_UPPER[char])
        elif char in GREEK_LOWER:
            result.append(GREEK_LOWER[char])
        else:
            result.append(char)
    return ''.join(result)


def to_cyrillic(text: str) -> str:
    """Convert Latin text to Cyrillic lookalikes where possible"""
    result = []
    for char in text:
        if char in CYRILLIC_UPPER:
            result.append(CYRILLIC_UPPER[char])
        elif char in CYRILLIC_LOWER:
            result.append(CYRILLIC_LOWER[char])
        else:
            result.append(char)
    return ''.join(result)


def to_mixed(text: str) -> str:
    """Convert using best available lookalike from any script"""
    # Prioritize: Greek uppercase, Cyrillic lowercase, fallback original
    ALL_LOOKALIKES = {
        **GREEK_UPPER,
        **CYRILLIC_LOWER,
        **GREEK_LOWER,
    }
    result = []
    for char in text:
        result.append(ALL_LOOKALIKES.get(char, char))
    return ''.join(result)


def inject_zwsp(text: str, positions: list = None) -> str:
    """Inject zero-width spaces at specified positions (or between each char)"""
    if positions is None:
        return INVISIBLE['ZWSP'].join(text)
    result = list(text)
    for pos in sorted(positions, reverse=True):
        result.insert(pos, INVISIBLE['ZWSP'])
    return ''.join(result)


def inject_rlo(text: str) -> str:
    """Inject Right-to-Left Override to reverse display order"""
    return BIDI_OVERRIDES['RLO'] + text + BIDI_OVERRIDES['PDF']


def compare_bytes(original: str, modified: str) -> None:
    """Show byte-level comparison of two strings"""
    print(f"Original:  {original}")
    print(f"Bytes:     {original.encode('utf-8').hex()}")
    print(f"Modified:  {modified}")
    print(f"Bytes:     {modified.encode('utf-8').hex()}")
    print(f"Same?      {original == modified}")
    print(f"Look same? (visual inspection required)")


# Quick test
if __name__ == "__main__":
    test_strings = [
        "1Password",
        "BrowserSupport",
        "com.1password.1password",
    ]
    
    print("=" * 60)
    print("HOMOGLYPH ATTACK PAYLOADS")
    print("=" * 60)
    
    for s in test_strings:
        print(f"\nOriginal: {s}")
        print(f"Greek:    {to_greek(s)}")
        print(f"Cyrillic: {to_cyrillic(s)}")
        print(f"Mixed:    {to_mixed(s)}")
        print(f"ZWSP:     {inject_zwsp(s)[:30]}... (truncated)")
        
        # Byte comparison
        mixed = to_mixed(s)
        print(f"\nOriginal bytes: {s.encode('utf-8').hex()}")
        print(f"Mixed bytes:    {mixed.encode('utf-8').hex()}")
        print(f"Equal? {s == mixed}")
        print("-" * 40)
