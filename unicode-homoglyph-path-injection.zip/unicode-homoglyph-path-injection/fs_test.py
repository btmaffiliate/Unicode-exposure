#!/usr/bin/env python3
import os, tempfile, shutil

tmpdir = tempfile.mkdtemp()
orig = os.path.join(tmpdir, "1Password")
fake = os.path.join(tmpdir, "1Ρassword")

os.makedirs(orig)
os.makedirs(fake)
open(os.path.join(orig, "t"), "w").write("ORIGINAL")
open(os.path.join(fake, "t"), "w").write("FAKE")

a = open(os.path.join(orig, "t")).read()
b = open(os.path.join(fake, "t")).read()

print("VULNERABLE!" if a != b else "NOT VULNERABLE")
shutil.rmtree(tmpdir)
